package com.example.EmployeeManagementSystem;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    List<DepartmentProjection> findByName(String name);
    List<DepartmentSummary> findAll();
}
