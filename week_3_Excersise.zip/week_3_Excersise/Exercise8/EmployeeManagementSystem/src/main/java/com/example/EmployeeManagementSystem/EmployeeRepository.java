package com.example.EmployeeManagementSystem;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<EmployeeProjection> findByName(String name);
    List<EmployeeInfo> findByEmail(String email);
}
